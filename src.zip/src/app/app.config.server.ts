// Server rendering config removed — this project is client-only now.
// Keep a copy of the original file in source control history if you need SSR later.

