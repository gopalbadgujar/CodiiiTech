// Removed server-specific bootstrap (SSR) — this project is client-only now.
// If you need SSR later, add a separate server build with appropriate configuration.

